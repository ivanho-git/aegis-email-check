// content.js - robust token + retry + MutationObserver approach
const BACKEND_URL = "https://aegis-phising-email.onrender.com/".replace(/\/\/+$/,"/");
console.log("CLASSIFIER: content script loaded. BACKEND_URL=", BACKEND_URL);

// Global state
const pendingResults = new Map(); // id -> result
const appliedResults = new Set();  // id set applied
let observer = null;

// Listen for popup scan request
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message && message.type === "SCAN_INBOX") {
    scanInbox()
      .then(res => sendResponse({ ok: true }))
      .catch(err => {
        console.error("CLASSIFIER: scanInbox failed:", err);
        sendResponse({ ok: false, error: String(err) });
      });
    return true; // keep channel open
  }
});

// ---------------- helpers ----------------
function uuidv4() {
  // small unique token for this scan
  return 't' + Math.random().toString(36).slice(2, 10);
}
function normalize(s){ return String(s||"").trim().replace(/\s+/g," ").toLowerCase(); }
function mapModelLabelToCategory(label){
  if(!label) return "legit";
  const l = String(label).toLowerCase();
  if(l.includes("phish")) return "phishing";
  if(l.includes("llm")) return "ai_generated";
  return "legit";
}
function prettyBadge(cat){ if(cat==="phishing") return "PHISHING ⚠️"; if(cat==="ai_generated") return "AI ✨"; return "LEGIT ✓"; }
function clearAllBadges(){ document.querySelectorAll(".gmail-classifier-badge").forEach(e=>e.remove()); }

// attempt to append a badge to a subject element
function appendBadgeToSubject(subjectEl, category, score, modelLabel){
  if(!subjectEl) return;
  // remove older badge
  const old = subjectEl.querySelector(".gmail-classifier-badge");
  if(old) old.remove();
  const badge = document.createElement("span");
  badge.className = "gmail-classifier-badge";
  badge.innerText = prettyBadge(category);
  Object.assign(badge.style, {
    padding:"2px 6px", marginLeft:"8px", borderRadius:"10px",
    fontSize:"10px", fontWeight:"700", fontFamily:"Arial, sans-serif", display:"inline-block"
  });
  if(category==="phishing"){ badge.style.backgroundColor="#ffd6d6"; badge.style.color="#8b0000"; badge.title = `Phishing ${(score*100||0).toFixed(0)}% — ${modelLabel}`; }
  else if(category==="ai_generated"){ badge.style.backgroundColor="#efe0ff"; badge.style.color="#4b2b8d"; badge.title = `LLM ${(score*100||0).toFixed(0)}% — ${modelLabel}`; }
  else { badge.style.backgroundColor="#e6ffe6"; badge.style.color="#006600"; badge.title = `Likely legit ${(score*100||0).toFixed(0)}% — ${modelLabel}`; }
  subjectEl.appendChild(badge);
}

// find a visible row using token first, else fuzzy match
function findRowForResultUsingTokenOrText(result, tokenMap){
  // tokenMap: id -> token
  const token = tokenMap && tokenMap[result.id];
  if(token){
    const rowByToken = document.querySelector(`[data-classifier-token="${CSS.escape(token)}"]`);
    if(rowByToken){
      const subjectEl = rowByToken.querySelector("span.bog");
      return { row: rowByToken, subjectEl, matchedBy: "token" };
    }
  }

  // fallback fuzzy: match subject/snippet/from
  const rows = Array.from(document.querySelectorAll('tr[role="row"]'));
  const tSub = normalize(result.subject);
  const tSnp = normalize(result.snippet);
  const tFrom = normalize(result.from_ || "");
  for(const row of rows){
    const subjectEl = row.querySelector('span.bog');
    const snippetEl = row.querySelector('span.y2');
    const fromEl = row.querySelector('span.yX.xY span.zF') || row.querySelector('.yW span');
    if(!subjectEl || !snippetEl || !fromEl) continue;
    const s = normalize(subjectEl.innerText);
    const sn = normalize(snippetEl.innerText);
    const f = normalize(fromEl.innerText);
    // exact/contains heuristic
    if(s === tSub || (tSub.length>5 && s.includes(tSub)) ) return { row, subjectEl, matchedBy: "subject-fuzzy" };
    if(tSnp && (sn.includes(tSnp) || tSnp.includes(sn))) return { row, subjectEl, matchedBy: "snippet-fuzzy" };
    if(tFrom && (f.includes(tFrom) || tFrom.includes(f))) return { row, subjectEl, matchedBy: "from-fuzzy" };
  }
  return null;
}

// ---------------- network ----------------
async function classifyEmails(payload){
  const endpoint = new URL("classify_emails", BACKEND_URL).toString();
  console.log("CLASSIFIER: POST", endpoint, "size", payload.length);
  const res = await fetch(endpoint, {
    method: "POST",
    headers: { "Content-Type":"application/json" },
    body: JSON.stringify({ emails: payload })
  });
  if(!res.ok){
    const text = await res.text().catch(()=>"<no-body>");
    throw new Error(`Backend ${res.status}: ${text}`);
  }
  return res.json();
}

// ---------------- main flow ----------------
async function scanInbox(){
  // prepare visible rows and attach tokens
  const rows = Array.from(document.querySelectorAll('tr[role="row"]'));
  const visibleEmails = [];
  const token = uuidv4();
  const tokenMap = {}; // id -> tokenVal

  rows.forEach((row, idx) => {
    const subjectEl = row.querySelector('span.bog');
    const snippetEl = row.querySelector('span.y2');
    const fromEl = row.querySelector('span.yX.xY span.zF') || row.querySelector('.yW span');
    if(subjectEl && snippetEl && fromEl){
      const id = `r${idx}`;
      const tokenVal = `${token}-${idx}`;
      // assign data attribute (may be removed by Gmail but usually persists briefly)
      try { row.setAttribute("data-classifier-token", tokenVal); } catch(e){}
      tokenMap[id] = tokenVal;
      visibleEmails.push({
        id,
        from_: fromEl.innerText.trim(),
        subject: subjectEl.innerText.trim(),
        snippet: snippetEl.innerText.trim()
      });
    }
  });

  if(!visibleEmails.length){
    console.warn("CLASSIFIER: no visible emails found");
    chrome.storage.local.set({ scanStatus:{ state:"idle", progress:0, total:0 } });
    return;
  }

  chrome.storage.local.set({ scanStatus:{ state:"scanning", progress:0, total: visibleEmails.length } });
  console.log("CLASSIFIER: visibleEmails", visibleEmails.length);

  const reply = await classifyEmails(visibleEmails);
  console.log("CLASSIFIER: server reply", reply);

  const results = (reply && reply.results) || [];
  // clear old badges to avoid duplicates
  clearAllBadges();
  pendingResults.clear();
  appliedResults.clear();

  // populate pendingResults and attempt to apply now
  results.forEach(r => {
    pendingResults.set(r.id, r);
  });

  // try immediate apply by token or fuzzy
  tryApplyAllOnce(tokenMap);

  // if some remain pending, set up mutation observer + retries for short period
  const remaining = Array.from(pendingResults.keys());
  if(remaining.length){
    console.log("CLASSIFIER: remaining to apply:", remaining.length, " — setting observer/retries");
    setupObserverAndRetries(tokenMap);
  }

  // compute counts and save for popup
  const counts = { phishing:0, ai_generated:0, legit:0 };
  results.forEach(r => {
    const cat = mapModelLabelToCategory(r.label);
    counts[ cat === "phishing" ? "phishing" : (cat==="ai_generated" ? "ai_generated" : "legit") ]++;
  });

  chrome.storage.local.set({
    lastClassification: { results, counts, timestamp: Date.now() },
    scanStatus: { state:"done", progress: results.length, total: visibleEmails.length, lastScan: Date.now() }
  });

  return results;
}

// try to apply all pending results once
function tryApplyAllOnce(tokenMap){
  for(const [id, result] of Array.from(pendingResults.entries())){
    const match = findRowForResultUsingTokenOrText(result, tokenMap);
    if(match){
      const cat = mapModelLabelToCategory(result.label);
      appendBadgeToSubject(match.subjectEl, cat, result.score || 0, result.label);
      appliedResults.add(id);
      pendingResults.delete(id);
      console.log("CLASSIFIER: applied", id, "by", match.matchedBy, "->", result.label);
    } else {
      // leave in pending
    }
  }
}

// observer + retry logic
function setupObserverAndRetries(tokenMap){
  let attempts = 0;
  const maxAttempts = 8;
  const intervalMs = 700;

  if(observer) { observer.disconnect(); observer = null; }

  observer = new MutationObserver((mutations) => {
    // on DOM changes, attempt to apply pending items
    if(pendingResults.size === 0) { observer.disconnect(); observer = null; return; }
    tryApplyAllOnce(tokenMap);
  });

  // watch top-level container that holds inbox rows (use body as fallback)
  const root = document.querySelector("div[role='main']") || document.body;
  observer.observe(root, { childList:true, subtree:true });

  // also keep a retry interval for a few seconds
  const interval = setInterval(() => {
    attempts++;
    if(pendingResults.size === 0 || attempts >= maxAttempts){
      clearInterval(interval);
      if(observer){ observer.disconnect(); observer = null; }
      if(pendingResults.size){
        console.warn("CLASSIFIER: some results could not be matched after retries:", Array.from(pendingResults.keys()));
        // still save storage but mark unmatched
        // keep them in lastClassification results (popup can show them)
      } else {
        console.log("CLASSIFIER: all pending applied");
      }
    } else {
      tryApplyAllOnce(tokenMap);
    }
  }, intervalMs);
}

// expose small API for debugging in console if needed
window.CLASSIFIER_debug_pending = () => ({ pending: Array.from(pendingResults.keys()), applied: Array.from(appliedResults) });

