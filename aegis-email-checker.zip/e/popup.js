// popup.js - supports 4-class backend, groups into 3 categories for pie chart

// map the 4-class labels to our 3 categories
function mapLabelToCategory(label) {
  label = String(label || "").toLowerCase();
  if (label.includes("phish")) return "phishing";
  if (label.includes("llm")) return "ai_generated";
  return "legit";
}

// produce counts grouped by category
function countsFromResults(results) {
  const counts = { legit: 0, ai_generated: 0, phishing: 0 };
  (results || []).forEach(r => {
    const cat = mapLabelToCategory(r.label);
    counts[cat] = (counts[cat] || 0) + 1;
  });
  return counts;
}

function renderPie(counts) {
  const total = counts.legit + counts.ai_generated + counts.phishing;
  const chart = document.getElementById("chart");
  chart.innerHTML = "";
  if (!total) {
    chart.innerHTML = "<div style='color:#666;padding:80px 10px'>No data</div>";
    return;
  }
  const colors = { legit: "#9bd39b", ai_generated: "#d9c7ff", phishing: "#ffb3b3" };
  const values = [counts.legit, counts.ai_generated, counts.phishing];
  const size = 210;
  const radius = size / 2;
  let angle = -90;
  const svgNS = "http://www.w3.org/2000/svg";
  const svg = document.createElementNS(svgNS, "svg");
  svg.setAttribute("width", size);
  svg.setAttribute("height", size);
  svg.style.display = "block";

  const labels = ["legit","ai_generated","phishing"];
  for (let i = 0; i < values.length; i++) {
    if (!values[i]) continue;
    const portion = values[i] / total;
    const sweep = portion * 360;
    const start = angle;
    const end = angle + sweep;
    const large = sweep > 180 ? 1 : 0;
    const x1 = radius + radius * Math.cos((Math.PI * start) / 180);
    const y1 = radius + radius * Math.sin((Math.PI * start) / 180);
    const x2 = radius + radius * Math.cos((Math.PI * end) / 180);
    const y2 = radius + radius * Math.sin((Math.PI * end) / 180);
    const path = document.createElementNS(svgNS, "path");
    const d = [`M ${radius} ${radius}`, `L ${x1} ${y1}`, `A ${radius} ${radius} 0 ${large} 1 ${x2} ${y2}`, "Z"].join(" ");
    path.setAttribute("d", d);
    path.setAttribute("fill", colors[labels[i]]);
    path.setAttribute("stroke", "#fff");
    path.setAttribute("stroke-width", "1");
    svg.appendChild(path);
    angle += sweep;
  }

  const text = document.createElementNS(svgNS, "text");
  text.setAttribute("x", radius);
  text.setAttribute("y", radius+6);
  text.setAttribute("text-anchor", "middle");
  text.setAttribute("font-size", "14");
  text.setAttribute("font-weight", "700");
  text.textContent = `${total}`;
  svg.appendChild(text);

  chart.appendChild(svg);
}

function renderResults(storageObj) {
  const resultsDiv = document.getElementById("results");
  resultsDiv.innerHTML = "";
  const results = (storageObj && storageObj.results) || [];
  if (!results.length) {
    resultsDiv.innerHTML = "<div class='small'>No scan results yet. Click Scan Inbox.</div>";
    return;
  }
  // show top 8 (full array exists in storage)
  const top = results.slice(0, 8);
  top.forEach(r => {
    const el = document.createElement("div");
    el.className = "row";
    el.style.borderBottom = "1px solid #eee";
    el.style.padding = "6px 0";
    // show original model label and mapped category
    const cat = mapLabelToCategory(r.label);
    const pretty = cat === "phishing" ? "PHISHING ⚠️" : (cat === "ai_generated" ? "AI ✨" : "LEGIT ✓");
    el.innerHTML = `<div style="width:70%"><div style="font-weight:700">${pretty} <span style="font-size:11px;color:#666;margin-left:6px">(${r.label})</span></div><div style="font-size:11px;color:#555">${r.id}</div></div><div style="text-align:right">${(r.score*100).toFixed(0)}%</div>`;
    resultsDiv.appendChild(el);
  });
}

function updateUI(lastClassification, scanStatus) {
  const last = lastClassification || null;
  const counts = last ? last.counts : {legit:0, ai_generated:0, phishing:0};

  // BUT: if model is 4-class we may need to remap counts from raw results
  if (last && Array.isArray(last.results) && last.results.length) {
    const remapped = countsFromResults(last.results);
    document.getElementById("count-legit").innerText = remapped.legit || 0;
    document.getElementById("count-ai").innerText = remapped.ai_generated || 0;
    document.getElementById("count-phish").innerText = remapped.phishing || 0;
    renderPie(remapped);
  } else {
    document.getElementById("count-legit").innerText = counts.legit || 0;
    document.getElementById("count-ai").innerText = counts.ai_generated || 0;
    document.getElementById("count-phish").innerText = counts.phishing || 0;
    renderPie(counts);
  }

  // last scan timestamp
  const ts = last && last.timestamp ? new Date(last.timestamp) : null;
  document.getElementById("lastScan").innerText = ts ? "Last: " + ts.toLocaleString() : "";

  // status/progress
  const statusText = document.getElementById("statusText");
  const progressEl = document.getElementById("progress");
  const scanBtn = document.getElementById("scan-btn");
  if (!scanStatus) {
    statusText.innerText = "Status: Idle";
    progressEl.style.display = "none";
    scanBtn.disabled = false;
  } else {
    if (scanStatus.state === "scanning" || scanStatus.state === "posting" || scanStatus.state === "processing") {
      statusText.innerText = "Status: Scanning...";
      progressEl.style.display = "block";
      const prog = scanStatus.progress || 0;
      const tot = scanStatus.total || 0;
      progressEl.innerText = `Scanning ${prog}/${tot}`;
      scanBtn.disabled = true;
    } else if (scanStatus.state === "done") {
      statusText.innerText = "Status: Done";
      progressEl.style.display = "none";
      scanBtn.disabled = false;
      if (scanStatus.lastScan) {
        document.getElementById("lastScan").innerText = "Last: " + new Date(scanStatus.lastScan).toLocaleString();
      }
    } else if (scanStatus.state === "error") {
      statusText.innerText = "Status: Error: " + (scanStatus.message || "");
      progressEl.style.display = "none";
      scanBtn.disabled = false;
    } else {
      statusText.innerText = "Status: " + scanStatus.state;
      progressEl.style.display = "none";
      scanBtn.disabled = false;
    }
  }

  renderResults(last);
}

function loadAndRender() {
  chrome.storage.local.get(["lastClassification", "scanStatus"], (obj) => {
    const last = obj && obj.lastClassification ? obj.lastClassification : null;
    const ss = obj && obj.scanStatus ? obj.scanStatus : null;
    updateUI(last, ss);
  });
}

async function injectIfNeededAndScan() {
  const tabs = await new Promise(res => chrome.tabs.query({ active: true, currentWindow: true }, res));
  if (!tabs || !tabs[0]) { alert("Open Gmail tab first"); return; }
  const tabId = tabs[0].id;

  chrome.tabs.sendMessage(tabId, { type: "SCAN_INBOX" }, (resp) => {
    if (chrome.runtime.lastError) {
      console.warn("sendMessage failed:", chrome.runtime.lastError.message);
      // try injecting
      chrome.scripting.executeScript({ target: { tabId }, files: ["content.js"] }, (res) => {
        if (chrome.runtime.lastError) {
          alert("Could not inject content script: " + chrome.runtime.lastError.message);
          return;
        }
        setTimeout(() => {
          chrome.tabs.sendMessage(tabId, { type: "SCAN_INBOX" }, (resp2) => {
            if (chrome.runtime.lastError) {
              alert("Error after injecting: " + chrome.runtime.lastError.message);
            } else {
              setTimeout(loadAndRender, 900);
            }
          });
        }, 300);
      });
    } else {
      setTimeout(loadAndRender, 900);
    }
  });
}

document.addEventListener("DOMContentLoaded", () => {
  document.getElementById("scan-btn").addEventListener("click", injectIfNeededAndScan);
  document.getElementById("refresh-btn").addEventListener("click", loadAndRender);

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === "local" && (changes.lastClassification || changes.scanStatus)) {
      loadAndRender();
    }
  });

  loadAndRender();
});
